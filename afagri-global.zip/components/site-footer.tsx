import { Mail, MapPin, Phone } from "lucide-react"

export function SiteFooter() {
  return (
    <footer className="bg-green-900 text-white py-12">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">About Us</h3>
            <p className="text-green-100">
              AFAGRI GLOBAL LIMITED is a leading exporter of cashews and pulses from West and East Africa, serving
              clients in India and Vietnam.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="/" className="text-green-100 hover:text-white">
                  Home
                </a>
              </li>
              <li>
                <a href="/about" className="text-green-100 hover:text-white">
                  About Us
                </a>
              </li>
              <li>
                <a href="/services" className="text-green-100 hover:text-white">
                  Our Services
                </a>
              </li>
              <li>
                <a href="/contact" className="text-green-100 hover:text-white">
                  Contact Us
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Contact Info</h3>
            <div className="space-y-4 text-green-100">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>+225 763 049 279</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>siddharth@afagri.net</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                <span>P.O. BOX 8606, Dar Es Salaam, Tanzania</span>
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-green-800 mt-8 pt-8 text-center text-green-100">
          <p>Registration No.: 146814190</p>
          <p>&copy; 2024 AFAGRI GLOBAL LIMITED. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}


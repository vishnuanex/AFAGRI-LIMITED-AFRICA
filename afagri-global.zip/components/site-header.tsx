import Link from "next/link"
import { Phone, Mail, MapPin } from "lucide-react"

export function SiteHeader() {
  return (
    <header className="w-full bg-white border-b">
      <div className="container flex justify-between items-center py-4 text-sm">
        <div className="font-bold text-xl text-green-800">AFAGRI GLOBAL LIMITED</div>
        <div className="hidden md:flex items-center gap-6">
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 text-green-600" />
            <div>
              <p className="text-gray-600">Call Us</p>
              <a href="tel:+225763049279" className="hover:text-green-600">
                +225 763 049 279
              </a>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Mail className="h-4 w-4 text-green-600" />
            <div>
              <p className="text-gray-600">Email Us</p>
              <a href="mailto:siddharth@afagri.net" className="hover:text-green-600">
                siddharth@afagri.net
              </a>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-green-600" />
            <div>
              <p className="text-gray-600">Location</p>
              <p>Dar Es Salaam, Tanzania</p>
            </div>
          </div>
        </div>
      </div>
      <nav className="bg-gradient-to-r from-green-50 via-white to-green-50">
        <div className="container">
          <ul className="flex flex-wrap items-center gap-8 py-4">
            <li>
              <Link href="/" className="font-medium hover:text-green-600 transition-colors">
                HOME
              </Link>
            </li>
            <li>
              <Link href="/about" className="font-medium hover:text-green-600 transition-colors">
                ABOUT US
              </Link>
            </li>
            <li>
              <Link href="/services" className="font-medium hover:text-green-600 transition-colors">
                OUR SERVICES
              </Link>
            </li>
            <li>
              <Link href="/products" className="font-medium hover:text-green-600 transition-colors">
                PRODUCTS
              </Link>
            </li>
            <li>
              <Link href="/contact" className="font-medium hover:text-green-600 transition-colors">
                CONTACT US
              </Link>
            </li>
          </ul>
        </div>
      </nav>
    </header>
  )
}


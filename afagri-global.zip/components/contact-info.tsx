import { Mail, MapPin, Phone } from "lucide-react"

export function ContactInfo() {
  return (
    <div className="space-y-6">
      <div className="flex items-start gap-4">
        <div className="bg-green-50 p-3 rounded-full">
          <Phone className="w-6 h-6 text-green-600" />
        </div>
        <div>
          <h3 className="font-bold mb-1 text-green-800">Phone</h3>
          <p className="text-gray-700">+225 763 049 279</p>
        </div>
      </div>
      <div className="flex items-start gap-4">
        <div className="bg-green-50 p-3 rounded-full">
          <Mail className="w-6 h-6 text-green-600" />
        </div>
        <div>
          <h3 className="font-bold mb-1 text-green-800">Email</h3>
          <p className="text-gray-700">siddharth@afagri.net</p>
        </div>
      </div>
      <div className="flex items-start gap-4">
        <div className="bg-green-50 p-3 rounded-full">
          <MapPin className="w-6 h-6 text-green-600" />
        </div>
        <div>
          <h3 className="font-bold mb-1 text-green-800">Address</h3>
          <p className="text-gray-700">P.O. BOX 8606, Dar Es Salaam, Tanzania</p>
        </div>
      </div>
      <div className="pt-4 border-t">
        <h3 className="font-bold mb-1 text-green-800">Registration No.</h3>
        <p className="text-gray-700">146814190</p>
      </div>
    </div>
  )
}


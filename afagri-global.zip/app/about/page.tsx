import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ContactInfo } from "@/components/contact-info"

export default function AboutPage() {
  return (
    <>
      <section className="bg-gray-50 py-16">
        <div className="container">
          <h1 className="text-4xl font-bold text-center mb-12">About AFAGRI GLOBAL LIMITED</h1>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <Image
                src="/placeholder.svg"
                alt="AFAGRI GLOBAL LIMITED facility"
                width={600}
                height={400}
                className="rounded-lg"
              />
            </div>
            <div className="space-y-6">
              <p className="text-gray-600">
                Welcome to AFAGRI GLOBAL LIMITED, a trusted name in cashew and pulses export from West and East Africa.
                With a strong commitment to quality, we ensure our products meet the highest standards at the port of
                destination, providing satisfaction to our successful clients in India and Vietnam.
              </p>
              <p className="text-gray-600">
                Our expertise in the agricultural export industry allows us to deliver premium products while
                maintaining the highest levels of service and reliability.
              </p>
              <Button>Our Services</Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Us</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Quality Assurance",
                description: "Rigorous quality control processes to ensure premium products",
              },
              {
                title: "Global Network",
                description: "Strong presence in international markets with reliable partnerships",
              },
              {
                title: "Expert Team",
                description: "Experienced professionals dedicated to excellence in service",
              },
            ].map((feature) => (
              <div key={feature.title} className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-bold mb-4">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <ContactInfo />
    </>
  )
}


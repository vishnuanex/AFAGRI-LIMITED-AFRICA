import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ContactInfo } from "@/components/contact-info"

const products = [
  {
    category: "Cashews",
    items: ["Raw Cashew Nuts", "Processed Cashews", "Cashew Kernels"],
  },
  {
    category: "Pulses",
    items: ["Lentils", "Chickpeas", "Beans", "Peas"],
  },
]

export default function ProductsPage() {
  return (
    <>
      <section className="bg-gray-50 py-16">
        <div className="container">
          <h1 className="text-4xl font-bold text-center mb-12">Our Products</h1>
          <div className="grid gap-12">
            {products.map((category) => (
              <div key={category.category} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="grid md:grid-cols-2">
                  <Image
                    src="/placeholder.svg"
                    alt={category.category}
                    width={600}
                    height={400}
                    className="object-cover h-full"
                  />
                  <div className="p-8">
                    <h2 className="text-2xl font-bold mb-6">{category.category}</h2>
                    <ul className="space-y-4">
                      {category.items.map((item) => (
                        <li key={item} className="flex items-center gap-2">
                          <span className="h-2 w-2 bg-primary rounded-full" />
                          {item}
                        </li>
                      ))}
                    </ul>
                    <Button className="mt-8">Request Quote</Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <ContactInfo />
    </>
  )
}


import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ContactInfo } from "@/components/contact-info"

export default function ServicesPage() {
  return (
    <>
      <section className="bg-gray-50 py-16">
        <div className="container">
          <h1 className="text-4xl font-bold text-center mb-12">Our Services</h1>
          <div className="grid gap-12">
            {[
              {
                title: "Export of Premium Quality Cashews and Pulses",
                description:
                  "We specialize in exporting high-grade cashews and pulses from West and East Africa to global markets.",
                image: "/placeholder.svg",
              },
              {
                title: "Guaranteed Quality Assurance",
                description:
                  "Our rigorous quality control ensures that all products meet the highest standards at the port of destination.",
                image: "/placeholder.svg",
              },
              {
                title: "Reliable Supply Chain Management",
                description:
                  "We manage the entire supply chain process, from sourcing to delivery, ensuring timely and efficient service.",
                image: "/placeholder.svg",
              },
            ].map((service, index) => (
              <div
                key={service.title}
                className={`grid md:grid-cols-2 gap-8 items-center ${index % 2 !== 0 ? "md:flex-row-reverse" : ""}`}
              >
                <Image
                  src={service.image || "/placeholder.svg"}
                  alt={service.title}
                  width={600}
                  height={400}
                  className="rounded-lg"
                />
                <div>
                  <h2 className="text-2xl font-bold mb-4">{service.title}</h2>
                  <p className="text-gray-600 mb-6">{service.description}</p>
                  <Button>Learn More</Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <ContactInfo />
    </>
  )
}


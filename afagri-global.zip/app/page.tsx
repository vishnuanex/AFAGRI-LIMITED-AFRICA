import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { ContactInfo } from "@/components/contact-info"

export default function Home() {
  return (
    <>
      <section className="relative h-[600px] flex items-center justify-center">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-leiliane-dutra-1841922-11108499.jpg-7qlRl4koz8zts18aT4xo3ZhxhaFyx1.jpeg"
          alt="Young seedling sprouting from soil, representing growth and sustainability"
          fill
          className="object-cover brightness-75"
          priority
        />
        <div className="relative container text-center text-white">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 drop-shadow-lg">AFAGRI GLOBAL LIMITED</h1>
          <p className="text-xl mb-8 max-w-2xl mx-auto drop-shadow-lg">
            Cashew and Pulses Exporting Company | West & East Africa
          </p>
          <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-black">
            Discover More
          </Button>
        </div>
      </section>

      <section className="py-16 pattern-bg">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="group">
              <div className="relative overflow-hidden rounded-2xl shadow-xl">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/cashew-3.jpg-RppSUzuUOUXX1Cedo5JZiKruGgqEy1.jpeg"
                  alt="Quality cashews"
                  width={500}
                  height={400}
                  className="object-cover transition duration-500 group-hover:scale-105"
                />
              </div>
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6 text-green-800">Welcome to AFAGRI GLOBAL LIMITED</h2>
              <p className="text-gray-700 mb-6">
                A trusted name in cashew and pulses export from West and East Africa. With a strong commitment to
                quality, we ensure our products meet the highest standards at the port of destination, providing
                satisfaction to our successful clients in India and Vietnam.
              </p>
              <Button className="bg-green-600 hover:bg-green-700">Learn More About Us</Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-b from-green-50/50 to-white">
        <div className="container">
          <h2 className="text-4xl font-bold text-center mb-12 text-green-800">Our Products</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="relative h-72">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/pexels-franco30-3658498.jpg-NckEKzgjXSefEp4nxkaZ0a1bixmXh0.jpeg"
                  alt="Fresh green cashews growing on the tree"
                  fill
                  className="object-cover transition duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-8 bg-white">
                <h3 className="text-2xl font-bold mb-3 text-green-800">Cashews</h3>
                <p className="text-gray-700">Premium quality cashews exported from West & East Africa.</p>
                <Button variant="ghost" className="mt-4 text-green-700 hover:text-green-800 hover:bg-green-50">
                  Learn More →
                </Button>
              </div>
            </div>
            <div className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="relative h-72">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Untitled-design-38-4ARE6AXDXUv2Cbjle4hCL0NynmsaX5.webp"
                  alt="Various types of pulses"
                  fill
                  className="object-cover transition duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-8 bg-white">
                <h3 className="text-2xl font-bold mb-3 text-green-800">Pulses</h3>
                <p className="text-gray-700">Premium quality pulses exported from West & East Africa.</p>
                <Button variant="ghost" className="mt-4 text-green-700 hover:text-green-800 hover:bg-green-50">
                  Learn More →
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 pattern-bg">
        <div className="container">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-3xl font-bold mb-8 text-center text-green-800">Contact Us</h2>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <ContactInfo />
              </div>
              <div>
                <form className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                      Name
                    </label>
                    <Input id="name" placeholder="Your Name" required />
                  </div>
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                      Phone
                    </label>
                    <Input id="phone" type="tel" placeholder="Your Phone Number" required />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <Input id="email" type="email" placeholder="Your Email" required />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                      Message
                    </label>
                    <Textarea id="message" placeholder="Your Message" rows={4} required />
                  </div>
                  <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
                    Send Message
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

